@echo off
chcp 65001 >nul
setlocal enabledelayedexpansion

title TPS Parser Installer (with venv and Neon)
color 0A

echo ===================================================
echo    TPS Parser Dependency Installer (with venv)
echo ===================================================
echo.

:: Check Python
python --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [ERROR] Python not found!
    echo.
    echo Please install Python 3.10 or higher from:
    echo https://www.python.org/downloads/
    echo.
    echo IMPORTANT: During installation, check "Add Python to PATH"
    pause
    exit /b 1
) else (
    for /f "tokens=2 delims= " %%i in ('python --version 2^>^&1') do set pyver=%%i
    echo [OK] Python found: !pyver!

    :: Check Python version (need 3.10+)
    for /f "tokens=1,2 delims=." %%a in ("!pyver!") do (
        set pymajor=%%a
        set pyminor=%%b
    )
    if !pymajor! lss 3 (
        echo [ERROR] Python 3.10 or higher required.
        pause
        exit /b 1
    )
    if !pymajor! equ 3 (
        if !pyminor! lss 10 (
            echo [ERROR] Python 3.10 or higher required.
            pause
            exit /b 1
        )
    )
)

:: Check pip in base Python (just for information)
python -m pip --version >nul 2>&1
if %errorlevel% neq 0 (
    echo [WARNING] pip not found in base Python, but we will use venv's pip.
) else (
    echo [OK] Base pip found
)

:: Create virtual environment
echo.
echo Creating virtual environment in .venv folder...
python -m venv .venv
if %errorlevel% neq 0 (
    echo [ERROR] Failed to create virtual environment.
    pause
    exit /b 1
)
echo [OK] Virtual environment created.

:: Activate virtual environment
echo.
echo Activating virtual environment...
call .venv\Scripts\activate.bat
if %errorlevel% neq 0 (
    echo [ERROR] Failed to activate virtual environment.
    pause
    exit /b 1
)
echo [OK] Virtual environment activated.

:: Upgrade pip in venv
echo.
echo Upgrading pip...
python -m pip install --upgrade pip

:: Install required packages
echo.
echo Installing required modules...
pip install playwright rich capmonstercloudclient aiohttp wmi customtkinter aiohttp-socks requests psycopg2-binary
if %errorlevel% neq 0 (
    echo.
    echo [ERROR] Failed to install modules.
    pause
    exit /b 1
)

:: Install Playwright browsers
echo.
echo Installing Playwright browsers...
playwright install chromium
if %errorlevel% neq 0 (
    echo.
    echo [ERROR] Failed to install browsers.
    pause
    exit /b 1
)

:: Create empty phones.txt if not exists
if not exist phones.txt (
    echo.
    echo Creating empty phones.txt...
    type nul > phones.txt
    echo [OK] phones.txt created.
)

:: Deactivate venv (optional, but good practice)
call deactivate

echo.
echo ===================================================
echo    Installation completed successfully!
echo ===================================================
echo.
echo To run the program:
echo   1. Activate the virtual environment:
echo      .venv\Scripts\activate
echo.
echo   2. Run the GUI:
echo      python gui.py   (or pythonw gui.pyw)
echo.
echo Or create a shortcut that runs:
echo   %~dp0.venv\Scripts\pythonw.exe gui.pyw
echo.
pause