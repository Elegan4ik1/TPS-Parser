import customtkinter as ctk
import subprocess
import threading
import json
import os
import sys
import time
import tkinter as tk
from tkinter import filedialog, messagebox
import asyncio
import aiohttp
from aiohttp_socks import ProxyConnector
import webbrowser
import requests  # для простых HTTP запросов

CONFIG_FILE = "config.json"
MAIN_SCRIPT = "main.py"
PROFILES_FILE = "profiles_log.txt"
CURRENT_VERSION = "1.0.2"  # ТЕКУЩАЯ ВЕРСИЯ ПРОГРАММЫ (меняйте при каждом релизе)

ctk.set_appearance_mode("dark")

class CollapsibleFrame(ctk.CTkFrame):
    # ... (класс без изменений, как в вашем коде) ...
    def __init__(self, parent, title, **kwargs):
        kwargs.setdefault("fg_color", "#161618")
        kwargs.setdefault("corner_radius", 12)
        kwargs.setdefault("border_width", 1)
        kwargs.setdefault("border_color", "#252529")
        super().__init__(parent, **kwargs)
        self.grid_columnconfigure(0, weight=1)
        self.is_collapsed = False

        self.header = ctk.CTkFrame(self, fg_color="transparent")
        self.header.grid(row=0, column=0, sticky="ew", padx=12, pady=8)
        self.header.grid_columnconfigure(0, weight=1)

        self.title_label = ctk.CTkLabel(
            self.header, text=title, font=("Segoe UI", 13, "bold"),
            text_color="#E0E1E2"
        )
        self.title_label.grid(row=0, column=0, sticky="w")

        self.toggle_btn = ctk.CTkButton(
            self.header, text="▼", width=24, height=24, corner_radius=6,
            fg_color="#252529", hover_color="#323238", command=self.toggle
        )
        self.toggle_btn.grid(row=0, column=1)

        self.content = ctk.CTkFrame(self, fg_color="transparent")
        self.content.grid(row=1, column=0, sticky="nsew", padx=12, pady=(0, 12))
        self.content.grid_columnconfigure(0, weight=1)

    def toggle(self):
        if self.is_collapsed:
            self.content.grid()
            self.toggle_btn.configure(text="▼")
        else:
            self.content.grid_remove()
            self.toggle_btn.configure(text="▶")
        self.is_collapsed = not self.is_collapsed


class ParserGUI(ctk.CTk):
    def __init__(self):
        super().__init__()
        self.title("TPS Parser v6.2 | Professional Edition")
        self.geometry("1600x900")
        self.configure(fg_color="#0F0F10")

        self.process = None
        self.running = False
        self.start_time = None
        self.processed_count = 0
        self.success_count = 0
        self.trash_count = 0
        self.total_numbers = 0

        self.config = self.load_config()
        self.vars = {}
        self.settings_visible = False

        self.create_layout()
        self.create_settings_cards()
        self.update_speed_display()
        self.update_percent_display()
        self.update_profiles_display()

        # Показываем версию в статусной строке (добавим рядом с "Готов к работе")
        self.version_label = ctk.CTkLabel(
            self.status_bar, text=f"v{CURRENT_VERSION}", anchor="e",
            font=("Segoe UI", 10), text_color="#94A3B8"
        )
        self.version_label.place(relx=1.0, x=-10, y=5, anchor="ne")

        # Скрываем левую панель и перераспределяем веса колонок
        self.left_scroll.grid_remove()
        self.grid_columnconfigure(0, weight=0, minsize=0)
        self.grid_columnconfigure(1, weight=1, minsize=400)
        self.grid_columnconfigure(2, weight=2, minsize=500)

        self.settings_btn = ctk.CTkButton(
            self, text="⚙️ Настройки", width=100,
            command=self.toggle_settings,
            fg_color="#252529", hover_color="#323238"
        )
        self.settings_btn.place(relx=1.0, x=-20, y=20, anchor="ne")

    def load_config(self):
        if os.path.exists(CONFIG_FILE):
            try:
                with open(CONFIG_FILE, 'r', encoding='utf-8') as f:
                    return json.load(f)
            except:
                return {}
        return {}

    def save_config(self):
        new_config = {}
        for key, var in self.vars.items():
            val = var.get()
            if key == "MULLVAD_COUNTRIES":
                new_config[key] = [x.strip() for x in val.split(',') if x.strip()]
            else:
                new_config[key] = val

        with open(CONFIG_FILE, 'w', encoding='utf-8') as f:
            json.dump(new_config, f, indent=4, ensure_ascii=False)
        self.status_var.set("✅ Конфигурация сохранена")
        self.after(2000, lambda: self.status_var.set("Готов к работе"))

        if self.settings_visible:
            self.toggle_settings()

    def toggle_settings(self):
        if self.settings_visible:
            self.left_scroll.grid_remove()
            self.grid_columnconfigure(0, weight=0, minsize=0)
            self.grid_columnconfigure(1, weight=1, minsize=400)
            self.grid_columnconfigure(2, weight=2, minsize=500)
            self.settings_btn.configure(text="⚙️ Настройки")
            self.settings_visible = False
        else:
            self.left_scroll.grid()
            self.grid_columnconfigure(0, weight=1, minsize=400)
            self.grid_columnconfigure(1, weight=1, minsize=400)
            self.grid_columnconfigure(2, weight=2, minsize=500)
            self.settings_btn.configure(text="✖️ Закрыть")
            self.settings_visible = True

    def create_layout(self):
        self.grid_columnconfigure(0, weight=1, minsize=400)
        self.grid_columnconfigure(1, weight=1, minsize=400)
        self.grid_columnconfigure(2, weight=2, minsize=500)
        self.grid_rowconfigure(0, weight=1)

        self.left_scroll = ctk.CTkScrollableFrame(self, corner_radius=0, fg_color="transparent")
        self.left_scroll.grid(row=0, column=0, padx=(20, 25), pady=20, sticky="nsew")
        self.left_scroll.grid_columnconfigure(0, weight=1)
        self.left_scroll.grid_columnconfigure(1, weight=0, minsize=25)

        self.mid_frame = ctk.CTkFrame(
            self, corner_radius=15, fg_color="#161618",
            border_width=1, border_color="#252529"
        )
        self.mid_frame.grid(row=0, column=1, padx=10, pady=20, sticky="nsew")
        self.mid_frame.grid_rowconfigure(1, weight=1)
        self.mid_frame.grid_columnconfigure(0, weight=1)

        mid_header = ctk.CTkFrame(self.mid_frame, fg_color="transparent", height=40)
        mid_header.grid(row=0, column=0, sticky="ew", padx=15, pady=(10, 0))
        mid_header.grid_columnconfigure(0, weight=1)
        ctk.CTkLabel(
            mid_header, text="📄 PROFILES_LOG.TXT", font=("Segoe UI", 13, "bold"),
            text_color="#E0E1E2"
        ).pack(side="left")

        self.profiles_text = ctk.CTkTextbox(
            self.mid_frame, wrap="word", font=("Consolas", 11),
            fg_color="#0A0A0B", text_color="#98FB98", border_width=0
        )
        self.profiles_text.grid(row=1, column=0, padx=0, pady=0, sticky="nsew")
        self.profiles_text.configure(state="disabled")

        self.right_frame = ctk.CTkFrame(
            self, corner_radius=15, fg_color="#161618",
            border_width=1, border_color="#252529"
        )
        self.right_frame.grid(row=0, column=2, padx=(10, 20), pady=20, sticky="nsew")
        self.right_frame.grid_rowconfigure(0, weight=1)
        self.right_frame.grid_columnconfigure(0, weight=1)

        self.log_text = ctk.CTkTextbox(
            self.right_frame, wrap="word", font=("Consolas", 12),
            fg_color="#0A0A0B", text_color="#98FB98", border_width=0
        )
        self.log_text.grid(row=0, column=0, padx=15, pady=15, sticky="nsew")

        self.log_text.tag_config("error", foreground="#EF4444")
        self.log_text.tag_config("success", foreground="#10B981")
        self.log_text.tag_config("warning", foreground="#F59E0B")
        self.log_text.tag_config("info", foreground="#3B82F6")
        self.log_text.tag_config("captcha", foreground="#A78BFA")
        self.log_text.tag_config("default", foreground="#98FB98")

        bottom_right_frame = ctk.CTkFrame(self.right_frame, fg_color="transparent")
        bottom_right_frame.grid(row=1, column=0, padx=15, pady=(0, 15), sticky="ew")
        bottom_right_frame.grid_columnconfigure(0, weight=1)

        self.progress_bar = ctk.CTkProgressBar(
            bottom_right_frame, height=8, progress_color="#3B82F6", fg_color="#252529"
        )
        self.progress_bar.grid(row=0, column=0, sticky="ew")
        self.progress_bar.set(0)

        self.percent_var = ctk.StringVar(value="0% (0/0)")
        self.percent_label = ctk.CTkLabel(
            bottom_right_frame, textvariable=self.percent_var,
            font=("Consolas", 11), text_color="#94A3B8"
        )
        self.percent_label.grid(row=0, column=1, padx=(10, 0))

        self.ctrl_panel = ctk.CTkFrame(
            self, height=140, fg_color="#161618",
            border_width=1, border_color="#252529"
        )
        self.ctrl_panel.grid(row=1, column=0, columnspan=3, sticky="ew")
        self.ctrl_panel.grid_columnconfigure((0, 1, 2), weight=1)

        self.save_btn = ctk.CTkButton(
            self.ctrl_panel, text="💾 СОХРАНИТЬ", fg_color="#3B82F6", hover_color="#2563EB",
            height=45, font=("Segoe UI", 12, "bold"), command=self.save_config
        )
        self.save_btn.grid(row=0, column=0, padx=20, pady=15, sticky="ew")

        self.start_btn = ctk.CTkButton(
            self.ctrl_panel, text="▶ ЗАПУСТИТЬ", fg_color="#10B981", hover_color="#059669",
            height=45, font=("Segoe UI", 12, "bold"), command=self.start_parsing
        )
        self.start_btn.grid(row=0, column=1, padx=20, pady=15, sticky="ew")

        self.stop_btn = ctk.CTkButton(
            self.ctrl_panel, text="⏹ ОСТАНОВИТЬ", fg_color="#EF4444", hover_color="#DC2626",
            height=45, font=("Segoe UI", 12, "bold"), command=self.stop_parsing, state="disabled"
        )
        self.stop_btn.grid(row=0, column=2, padx=20, pady=15, sticky="ew")

        self.info_frame = ctk.CTkFrame(self.ctrl_panel, fg_color="transparent")
        self.info_frame.grid(row=1, column=0, columnspan=3, sticky="ew", padx=20, pady=(0, 10))
        self.info_frame.grid_columnconfigure(0, weight=1)
        self.info_frame.grid_columnconfigure(1, weight=1)
        self.info_frame.grid_columnconfigure(2, weight=1)

        self.speed_var = ctk.StringVar(value="Скорость: -- н/мин")
        ctk.CTkLabel(
            self.info_frame, textvariable=self.speed_var,
            font=("Segoe UI", 11), text_color="#94A3B8"
        ).grid(row=0, column=0, sticky="w")

        self.stage_var = ctk.StringVar(value="Ожидание")
        ctk.CTkLabel(
            self.info_frame, textvariable=self.stage_var,
            font=("Segoe UI", 11, "italic"), text_color="#A78BFA"
        ).grid(row=0, column=1, sticky="w")

        self.status_var = ctk.StringVar(value="Готов к работе")
        ctk.CTkLabel(
            self.info_frame, textvariable=self.status_var,
            font=("Segoe UI", 11), text_color="#3B82F6"
        ).grid(row=0, column=2, sticky="e")

        self.status_bar = ctk.CTkLabel(
            self, textvariable=self.status_var, anchor="w",
            fg_color="#0F0F10", corner_radius=0, height=30, text_color="#3B82F6"
        )
        self.status_bar.grid(row=2, column=0, columnspan=3, sticky="ew", padx=0, pady=0)

    def add_row(self, parent, label_text, key, default="", is_boolean=False, is_int=False, show=None):
        frame = ctk.CTkFrame(parent, fg_color="transparent")
        frame.pack(fill="x", pady=4)
        ctk.CTkLabel(
            frame, text=label_text, width=220, anchor="w",
            font=("Segoe UI", 11), text_color="#94A3B8"
        ).pack(side="left")

        if is_boolean:
            var = ctk.BooleanVar(value=self.config.get(key, default))
            ctk.CTkSwitch(
                frame, text="", variable=var,
                progress_color="#10B981", button_color="#252529"
            ).pack(side="left")
        else:
            if key == "MULLVAD_COUNTRIES" and isinstance(self.config.get(key), list):
                val = ','.join(self.config[key])
            else:
                val = self.config.get(key, default)

            if is_int:
                var = ctk.IntVar(value=int(val) if val else 0)
            else:
                var = ctk.StringVar(value=str(val))

            entry = ctk.CTkEntry(
                frame, textvariable=var, height=32, show=show,
                fg_color="#0F0F10", border_color="#2D2D33", corner_radius=6
            )
            entry.pack(side="left", fill="x", expand=True)

            if "FILE" in key or key in ["CHROME_PATH", "BAT_FILE"]:
                ctk.CTkButton(
                    frame, text="📁", width=32, fg_color="#252529",
                    command=lambda: self.browse(var, key)
                ).pack(side="right", padx=(5, 0))

        self.vars[key] = var

    def browse(self, var, key):
        if key == "CHROME_PATH":
            filename = filedialog.askopenfilename(
                title="Выберите chrome.exe",
                filetypes=[("Executable", "*.exe")]
            )
        elif key == "BAT_FILE":
            filename = filedialog.askopenfilename(
                title="Выберите bat-файл",
                filetypes=[("Batch", "*.bat")]
            )
        else:
            filename = filedialog.askopenfilename(title="Выберите файл")
        if filename:
            var.set(filename)

    def create_settings_cards(self):
        card_launch = CollapsibleFrame(self.left_scroll, "🚀 ЗАПУСК")
        card_launch.grid(row=0, column=0, padx=10, pady=5, sticky="ew")
        self.add_row(card_launch.content, "Способ запуска:", "LAUNCH_METHOD", "main.py")
        self.add_row(card_launch.content, "Файл запуска (если выбран bat):", "BAT_FILE", "START_PARSER.bat")

        card_main = CollapsibleFrame(self.left_scroll, "🔧 ОСНОВНЫЕ")
        card_main.grid(row=1, column=0, padx=10, pady=5, sticky="ew")
        self.add_row(card_main.content, "Количество потоков:", "THREADS", 1, is_int=True)
        self.add_row(card_main.content, "Путь к Chrome (chrome.exe):", "CHROME_PATH", r"C:\Program Files\Google\Chrome\Application\chrome.exe")
        self.add_row(card_main.content, "Ключ CapMonster:", "CAPMONSTER_API_KEY", "0a0749fd9d27370ffd539562af7d41fa", show="*")

        card_delay = CollapsibleFrame(self.left_scroll, "⏱️ ЗАДЕРЖКИ")
        card_delay.grid(row=2, column=0, padx=10, pady=5, sticky="ew")
        self.add_row(card_delay.content, "Мин. задержка между номерами (сек):", "MIN_DELAY_BETWEEN", 3, is_int=True)
        self.add_row(card_delay.content, "Макс. задержка между номерами (сек):", "MAX_DELAY_BETWEEN", 6, is_int=True)
        self.add_row(card_delay.content, "Таймаут поиска (сек):", "SEARCH_WAIT_TIMEOUT", 20, is_int=True)

        card_files = CollapsibleFrame(self.left_scroll, "📁 ФАЙЛЫ")
        card_files.grid(row=3, column=0, padx=10, pady=5, sticky="ew")
        self.add_row(card_files.content, "Входной файл с номерами:", "INPUT_FILE", "phones.txt")
        self.add_row(card_files.content, "Файл результатов (профили):", "RESULT_FILE", "profiles_log.txt")
        self.add_row(card_files.content, "Файл для 'пустых' номеров (trash):", "TRASH_FILE", "trash.txt")

        card_network = CollapsibleFrame(self.left_scroll, "🌐 СЕТЬ")
        card_network.grid(row=4, column=0, padx=10, pady=5, sticky="ew")
        self.add_row(card_network.content, "Использовать Mullvad VPN:", "USE_MULLVAD", True, is_boolean=True)
        self.add_row(card_network.content, "Текущая страна Mullvad:", "MULLVAD_COUNTRY", "us")
        self.add_row(card_network.content, "Файл со списком прокси:", "PROXY_FILE", "proxies.txt")
        self.add_row(card_network.content, "Список стран для ротации (через запятую):", "MULLVAD_COUNTRIES", "us,ca")

        test_proxy_btn = ctk.CTkButton(
            card_network.content, text="🔄 Проверить прокси(в разработке)", command=self.test_proxy,
            corner_radius=6, height=30, fg_color="#252529", hover_color="#323238"
        )
        test_proxy_btn.pack(pady=5, padx=5, anchor="w")

        card_telegram = CollapsibleFrame(self.left_scroll, "📱 TELEGRAM")
        card_telegram.grid(row=5, column=0, padx=10, pady=5, sticky="ew")
        self.add_row(card_telegram.content, "Токен бота (TELEGRAM_BOT_TOKEN):", "TELEGRAM_BOT_TOKEN", "")
        self.add_row(card_telegram.content, "Chat ID (TELEGRAM_CHAT_ID):", "TELEGRAM_CHAT_ID", "")

        card_parsing = CollapsibleFrame(self.left_scroll, "🔍 ПАРСИНГ")
        card_parsing.grid(row=6, column=0, padx=10, pady=5, sticky="ew")
        self.add_row(card_parsing.content, "Минимальный возраст:", "MIN_AGE", 30, is_int=True)
        self.add_row(card_parsing.content, "Максимальный возраст:", "MAX_AGE", 55, is_int=True)
        self.add_row(card_parsing.content, "Селектор вкладки телефона:", "SEL_PHONE_TAB", "#searchTypePhone-d")
        self.add_row(card_parsing.content, "Селектор поля ввода:", "SEL_INPUT", "#id-d-ph")
        self.add_row(card_parsing.content, "Селектор кнопки Submit:", "SEL_SUBMIT", "#btnSubmit-d-ph")

        card_license = CollapsibleFrame(self.left_scroll, "🔐 ЛИЦЕНЗИЯ")
        card_license.grid(row=7, column=0, padx=10, pady=5, sticky="ew")
        self.add_row(card_license.content, "Лицензионный ключ:", "LICENSE_KEY", "", show="*")
        self.add_row(card_license.content, "URL GitHub с ключами:", "GITHUB_LICENSE_URL",
                    "https://gist.githubusercontent.com/Elegan4ik1/b7cf1858a40efae92da7ae63a8817f2c/raw/licenses.json")

        # Карточка: ДОПОЛНИТЕЛЬНО (добавляем кнопку проверки обновлений)
        card_extra = CollapsibleFrame(self.left_scroll, "⚙️ ДОПОЛНИТЕЛЬНО")
        card_extra.grid(row=8, column=0, padx=10, pady=5, sticky="ew")
        self.add_row(card_extra.content, "Проверять баланс CapMonster:", "CHECK_BALANCE", True, is_boolean=True)
        self.add_row(card_extra.content, "Детальный лог (debug.log):", "DEBUG_LOG", False, is_boolean=True)
        self.add_row(card_extra.content, "Макс. банов подряд до смены страны:", "MAX_CONSECUTIVE_BANS", 3, is_int=True)
        self.add_row(card_extra.content, "Штраф при банах (сек):", "BAN_PENALTY_SECONDS", 30, is_int=True)
        self.add_row(card_extra.content, "Neon DSN (строка подключения к БД):", "NEON_DSN", "")

        # 👇 КНОПКА ПРОВЕРКИ ОБНОВЛЕНИЙ
        update_btn = ctk.CTkButton(
            card_extra.content, text="🔄 Проверить обновления", command=self.check_for_updates,
            corner_radius=6, height=30, fg_color="#252529", hover_color="#323238"
        )
        update_btn.pack(pady=5, padx=5, anchor="w")

    # --- Методы для работы с прокси ---
    def test_proxy(self):
        proxy_file = self.vars.get("PROXY_FILE", ctk.StringVar(value="proxies.txt")).get()
        if not os.path.exists(proxy_file):
            self.status_var.set("❌ Файл прокси не найден")
            return
        try:
            with open(proxy_file, 'r', encoding='utf-8') as f:
                first_line = f.readline().strip()
            if not first_line:
                self.status_var.set("❌ Файл прокси пуст")
                return
            if not first_line.startswith(("http://", "https://", "socks5://")):
                proxy_url = f"http://{first_line}"
            else:
                proxy_url = first_line
            threading.Thread(target=self._test_proxy_async, args=(proxy_url,), daemon=True).start()
        except Exception as e:
            self.status_var.set(f"❌ Ошибка: {e}")

    def _test_proxy_async(self, proxy_url):
        async def check():
            try:
                async with aiohttp.ClientSession() as sess:
                    start = time.time()
                    async with sess.get("https://api.ipify.org", proxy=proxy_url, timeout=10) as resp:
                        if resp.status == 200:
                            data = await resp.json()
                            latency = (time.time() - start) * 1000
                            self.after(0, self.status_var.set, f"✅ Прокси работает: {data.get('origin')} ({latency:.0f} мс)")
                        else:
                            self.after(0, self.status_var.set, f"❌ Прокси вернул код {resp.status}")
            except Exception as e:
                self.after(0, self.status_var.set, f"❌ Ошибка прокси: {e}")
        asyncio.run(check())

    # --- НОВЫЙ МЕТОД: проверка обновлений на GitHub ---
    def check_for_updates(self):
        """Проверяет наличие новой версии на GitHub (в отдельном потоке)."""
        self.status_var.set("⏳ Проверка обновлений...")

        def _check():
            try:
                # URL до вашего version.json (замените на свой репозиторий)
                version_url = "https://raw.githubusercontent.com/ваш-username/ваш-репозиторий/main/version.json"
                response = requests.get(version_url, timeout=10)
                if response.status_code != 200:
                    self.after(0, self.status_var.set, "❌ Не удалось проверить обновления")
                    return

                data = response.json()
                latest_version = data.get("version")
                download_url = data.get("download_url")
                changelog = data.get("changelog", "Нет описания")
                required = data.get("required", False)

                if not latest_version or not download_url:
                    self.after(0, self.status_var.set, "❌ Неверный формат файла версий")
                    return

                # Сравниваем версии
                if latest_version > CURRENT_VERSION:
                    # Есть новая версия
                    msg = (f"Доступна новая версия: {latest_version}\n\n"
                           f"Текущая версия: {CURRENT_VERSION}\n\n"
                           f"Что нового:\n{changelog}\n\n"
                           f"Скачать обновление?")
                    if required:
                        msg += "\n\nЭто обновление рекомендуется к установке."

                    if messagebox.askyesno("Обновление", msg):
                        webbrowser.open(download_url)
                        self.after(0, self.status_var.set, f"✅ Страница загрузки открыта")
                    else:
                        self.after(0, self.status_var.set, "Готов к работе")
                else:
                    self.after(0, self.status_var.set, "✅ У вас актуальная версия")
                    self.after(2000, lambda: self.status_var.set("Готов к работе"))
            except requests.exceptions.RequestException as e:
                self.after(0, self.status_var.set, f"❌ Ошибка сети: {e}")
            except Exception as e:
                self.after(0, self.status_var.set, f"❌ Ошибка: {e}")

        threading.Thread(target=_check, daemon=True).start()

    # --- Логика запуска и парсинга вывода ---
    def start_parsing(self):
        if self.running:
            return
        self.save_config()

        method = self.vars.get("LAUNCH_METHOD", ctk.StringVar(value="main.py")).get()
        bat_file = self.vars.get("BAT_FILE", ctk.StringVar(value="START_PARSER.bat")).get()

        if method == "main.py":
            target = MAIN_SCRIPT
            if not os.path.exists(target):
                self.log(f"❌ Ошибка: файл {target} не найден!", "error")
                messagebox.showerror("Ошибка", f"Файл {target} не найден!")
                return
            cmd = [sys.executable, target, "--no-restore", "--simple-output", "--auto-install"]
        else:
            if not os.path.exists(bat_file):
                self.log(f"❌ Ошибка: файл {bat_file} не найден!", "error")
                messagebox.showerror("Ошибка", f"Файл {bat_file} не найден!")
                return
            cmd = [bat_file, "--no-restore", "--simple-output", "--auto-install"]

        self.log_text.delete("1.0", "end")
        self.log(f"🚀 Запуск парсера: {' '.join(cmd)}", "info")
        self.stage_var.set("Запуск")
        self.status_var.set("Парсер запущен...")
        self.running = True
        self.start_btn.configure(state="disabled")
        self.stop_btn.configure(state="normal")

        self.start_time = time.time()
        self.processed_count = 0
        self.success_count = 0
        self.trash_count = 0
        self.total_numbers = 0
        self.progress_bar.set(0)

        try:
            self.process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                bufsize=0,
                creationflags=subprocess.CREATE_NO_WINDOW if sys.platform == "win32" else 0
            )
            self.reader_thread = threading.Thread(target=self.read_output, daemon=True)
            self.reader_thread.start()
        except Exception as e:
            self.log(f"❌ Ошибка запуска: {e}", "error")
            self.parsing_finished()

    def read_output(self):
        while self.process and self.process.poll() is None:
            try:
                line_bytes = self.process.stdout.readline()
                if not line_bytes:
                    break
                try:
                    line = line_bytes.decode('utf-8', errors='replace').rstrip()
                except:
                    line = line_bytes.decode('cp1251', errors='replace').rstrip()

                tag = "default"
                if "❌" in line or "ошибка" in line.lower() or "exception" in line.lower():
                    tag = "error"
                elif "✅" in line or "успех" in line.lower() or "success" in line.lower():
                    tag = "success"
                elif "⚠️" in line or "предупреждение" in line.lower() or "warning" in line.lower():
                    tag = "warning"
                elif "капча" in line.lower() or "captcha" in line.lower():
                    tag = "captcha"
                elif "запуск" in line.lower() or "загрузка" in line.lower():
                    tag = "info"

                if "💾 Сохранён профиль" in line:
                    self.success_count += 1
                    self.processed_count += 1
                elif "🗑️" in line and "не найден" in line:
                    self.trash_count += 1
                    self.processed_count += 1
                elif "⏭️" in line:
                    self.processed_count += 1

                if line.startswith("TOTAL:"):
                    try:
                        self.total_numbers = int(line.split(":")[1].strip())
                    except:
                        pass

                self.after(0, self.log, line, tag)
                self.after(0, self.update_stage, line)
            except Exception as e:
                self.after(0, self.log, f"⚠️ Ошибка чтения вывода: {e}", "error")
                break
        self.after(0, self.parsing_finished)

    def log(self, message, tag="default"):
        self.log_text.insert("end", message + "\n", tag)
        self.log_text.see("end")
        self.update_idletasks()

    def update_stage(self, line):
        line_lower = line.lower()
        if "лицензия действительна" in line_lower or "license valid" in line_lower:
            self.stage_var.set("✅ Лицензия OK")
        elif "проверка лицензии" in line_lower:
            self.stage_var.set("🔑 Проверка лицензии")
        elif "баланс capmonster" in line_lower and "мало средств" not in line_lower:
            self.stage_var.set("💰 Проверка баланса")
        elif "мало средств" in line_lower:
            self.stage_var.set("⚠️ Мало средств на CapMonster")
        elif "mullvad" in line_lower:
            self.stage_var.set("🔄 Настройка Mullvad")
        elif "ввод номера" in line_lower:
            self.stage_var.set("📞 Ввод номера")
        elif "решение капчи" in line_lower:
            self.stage_var.set("🧩 Решение капчи")
        elif "токен получен" in line_lower:
            self.stage_var.set("🔑 Токен получен, вставляю...")
        elif "капча пройдена" in line_lower:
            self.stage_var.set("✅ Капча пройдена")
        elif "повторный submit" in line_lower:
            self.stage_var.set("🔄 Повторный Submit")
        elif "бан" in line_lower or "banned" in line_lower or "лимит" in line_lower:
            self.stage_var.set("🚫 Обнаружен бан, смена IP")
        elif "профиль" in line_lower and ("найден" in line_lower or "сохранён" in line_lower):
            self.stage_var.set("👤 Парсинг профиля")
        elif "успех" in line_lower or "success" in line_lower:
            self.stage_var.set("✅ Успешно")
        elif "заверш" in line_lower or "finished" in line_lower:
            self.stage_var.set("🏁 Завершено")
        elif "останавливаем" in line_lower:
            self.stage_var.set("🛑 Остановка")

    def parsing_finished(self):
        self.log("✅ Парсер завершил работу.", "success")
        self.stage_var.set("Завершён")
        self.status_var.set("Парсер завершён")
        self.running = False
        self.start_btn.configure(state="normal")
        self.stop_btn.configure(state="disabled")
        self.process = None

    def stop_parsing(self):
        if self.process and self.process.poll() is None:
            self.log("🛑 Останавливаем парсер...", "warning")
            self.stage_var.set("Остановка")
            self.status_var.set("Остановка...")
            if sys.platform == "win32":
                subprocess.run(f"taskkill /F /T /PID {self.process.pid}", shell=True)
            else:
                self.process.terminate()
        self.stop_btn.configure(state="disabled")

    def update_speed_display(self):
        if self.running and self.start_time:
            elapsed = (time.time() - self.start_time) / 60
            if elapsed > 0:
                speed = self.processed_count / elapsed
                self.speed_var.set(f"Скорость: {speed:.1f} н/мин")
        self.after(2000, self.update_speed_display)

    def update_percent_display(self):
        if self.total_numbers > 0:
            percent = (self.processed_count / self.total_numbers) * 100
            self.percent_var.set(f"{percent:.1f}% ({self.processed_count}/{self.total_numbers})")
            self.progress_bar.set(self.processed_count / self.total_numbers)
        else:
            self.percent_var.set("0% (0/0)")
            self.progress_bar.set(0)
        self.after(1000, self.update_percent_display)

    def update_profiles_display(self):
        try:
            if os.path.exists(PROFILES_FILE):
                with open(PROFILES_FILE, 'r', encoding='utf-8', errors='replace') as f:
                    content = f.read()
            else:
                content = "Файл не найден. Он будет создан при первом сохранении профиля."
        except Exception as e:
            content = f"Ошибка чтения файла: {e}"

        self.profiles_text.configure(state="normal")
        current = self.profiles_text.get("1.0", "end-1c")
        if current != content:
            self.profiles_text.delete("1.0", "end")
            self.profiles_text.insert("1.0", content)
        self.profiles_text.configure(state="disabled")
        self.after(2000, self.update_profiles_display)


if __name__ == "__main__":
    app = ParserGUI()
    app.mainloop()