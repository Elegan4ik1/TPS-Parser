import asyncio
import random
import winsound
import os
import sys
import re
import json
import subprocess
import time
import datetime
import signal
import hashlib
import uuid
from typing import Dict, Optional, Tuple, Set, List
import importlib.util

# Автоустановка зависимостей (добавлен psycopg2-binary)
required_packages = ['playwright', 'rich', 'capmonstercloudclient', 'aiohttp', 'wmi', 'psycopg2']
missing = []
for pkg in required_packages:
    if importlib.util.find_spec(pkg) is None:
        missing.append(pkg)
if missing:
    print(f"X Missing modules: {', '.join(missing)}")
    auto_install = '--auto-install' in sys.argv
    if auto_install:
        print("+ Auto-installing missing modules...")
        try:
            subprocess.check_call([sys.executable, "-m", "pip", "install"] + missing)
            print("+ Installation successful. Please restart the script.")
        except Exception as e:
            print(f"! Installation failed: {e}")
        sys.exit(0)
    else:
        answer = input("Install them now? (y/n): ").lower()
        if answer == 'y':
            subprocess.check_call([sys.executable, "-m", "pip", "install"] + missing)
            print("+ Installation complete. Restart the script.")
            sys.exit(0)
        else:
            print("! Script cannot run without dependencies. Exiting.")
            sys.exit(1)

from playwright.async_api import async_playwright, Page
from rich.console import Console
from rich.table import Table
from rich.live import Live
from rich.text import Text

from capmonstercloudclient import CapMonsterClient, ClientOptions
from capmonstercloudclient.requests import TurnstileRequest
import aiohttp
import psycopg2
from psycopg2 import pool

# Корректный вывод юникода в Windows-консоль
if sys.platform == "win32":
    import io
    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")

CONFIG_FILE = "config.json"
DEFAULT_CONFIG = {
    "THREADS": 1,
    "CHROME_PATH": r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    "CAPMONSTER_API_KEY": "0a0749fd9d27370ffd539562af7d41fa",
    "MIN_DELAY_BETWEEN": 1,
    "MAX_DELAY_BETWEEN": 2,
    "SEARCH_WAIT_TIMEOUT": 4,
    "INPUT_FILE": "phones.txt",
    "RESULT_FILE": "profiles_log.txt",
    "TRASH_FILE": "trash.txt",
    "USE_MULLVAD": True,
    "MULLVAD_COUNTRY": "us",
    "PROXY_FILE": "proxies.txt",
    "TELEGRAM_BOT_TOKEN": "8799773767:AAFAvzI58eLvB8t4wx_Cm7H1YzKI5HKsD64",
    "TELEGRAM_CHAT_ID": "-1003805471522",
    "CHECK_BALANCE": True,
    "MIN_AGE": 30,
    "MAX_AGE": 60,
    "SEL_PHONE_TAB": "#searchTypePhone-d",
    "SEL_INPUT": "#id-d-ph",
    "SEL_SUBMIT": "#btnSubmit-d-ph",
    "DEBUG_LOG": False,
    "MAX_CONSECUTIVE_BANS": 3,
    "BAN_PENALTY_SECONDS": 30,
    "MULLVAD_COUNTRIES": ["us", "ca"],
    "LICENSE_KEY": "",
    "GITHUB_LICENSE_URL": "https://gist.githubusercontent.com/Elegan4ik1/b7cf1858a40efae92da7ae63a8817f2c/raw/licenses.json",
    # Neon connection string
    "NEON_DSN": "postgresql://neondb_owner:npg_gtR5Az4yHIwa@ep-bitter-smoke-ae4tb53l-pooler.c-2.us-east-2.aws.neon.tech/neondb?sslmode=require&channel_binding=require"
}

def load_config() -> dict:
    if not os.path.exists(CONFIG_FILE):
        with open(CONFIG_FILE, "w", encoding="utf-8") as f:
            json.dump(DEFAULT_CONFIG, f, indent=4, ensure_ascii=False)
        return DEFAULT_CONFIG
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        user_cfg = json.load(f)
    full = DEFAULT_CONFIG.copy()
    full.update(user_cfg)
    return full

CONFIG = load_config()
console = Console()

# Для детального логирования
debug_log = None
if CONFIG.get("DEBUG_LOG", False):
    debug_log = open("debug.log", "a", encoding="utf-8")

def log_debug(message: str):
    if debug_log:
        timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        debug_log.write(f"[{timestamp}] {message}\n")
        debug_log.flush()

# Глобальная переменная для режима простого вывода
SIMPLE_MODE = False

# Статистика
stats = {
    "success": 0,
    "trash": 0,
    "banned": 0,
    "retry": 0,
    "total_unique": 0,
    "start_time": time.time(),
    "consecutive_bans": 0,
}
PHONE_DATES: dict[str, str] = {}

# Множество для отслеживания уже обработанных успешных номеров в текущей сессии
processed_success = set()

# CapMonster
cap_options = ClientOptions(api_key=CONFIG["CAPMONSTER_API_KEY"])
cap_client = CapMonsterClient(options=cap_options)

# --- КЛАСС ДЛЯ РАБОТЫ С NEON (POSTGRESQL) ---
class NeonStorage:
    """Хранит обработанные номера в Neon (PostgreSQL) с пулом соединений."""
    
    def __init__(self, dsn: str, min_conn: int = 1, max_conn: int = 10):
        self.dsn = dsn
        self.pool = None
        self._init_pool(min_conn, max_conn)
        self._init_db()
    
    def _init_pool(self, min_conn: int, max_conn: int):
        """Создаёт пул соединений."""
        try:
            self.pool = psycopg2.pool.SimpleConnectionPool(min_conn, max_conn, self.dsn)
        except Exception as e:
            print(f"Ошибка создания пула подключений к Neon: {e}")
            raise
    
    def _init_db(self):
        """Создаёт таблицу, если её нет."""
        conn = self._get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute("""
                    CREATE TABLE IF NOT EXISTS processed_phones (
                        phone VARCHAR(15) PRIMARY KEY,
                        status VARCHAR(20) DEFAULT 'processed',
                        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
                    );
                """)
            conn.commit()
        finally:
            self._return_connection(conn)
    
    def _get_connection(self):
        return self.pool.getconn()
    
    def _return_connection(self, conn):
        self.pool.putconn(conn)
    
    def phone_exists(self, phone: str) -> bool:
        """Проверяет существование номера в БД."""
        conn = self._get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute("SELECT 1 FROM processed_phones WHERE phone = %s", (phone,))
                return cur.fetchone() is not None
        finally:
            self._return_connection(conn)
    
    def add_phone(self, phone: str):
        """Добавляет номер в БД, если его ещё нет (ON CONFLICT DO NOTHING)."""
        conn = self._get_connection()
        try:
            with conn.cursor() as cur:
                cur.execute("""
                    INSERT INTO processed_phones (phone) VALUES (%s)
                    ON CONFLICT (phone) DO NOTHING
                """, (phone,))
            conn.commit()
        finally:
            self._return_connection(conn)

# --- ФУНКЦИИ ЛИЦЕНЗИРОВАНИЯ (ДОБАВЛЕНЫ) ---
def get_hwid() -> str:
    try:
        if sys.platform == "win32":
            import wmi
            c = wmi.WMI()
            for disk in c.Win32_DiskDrive():
                if disk.SerialNumber:
                    return hashlib.sha256(disk.SerialNumber.strip().encode()).hexdigest()[:16]
        mac = uuid.getnode()
        return hashlib.sha256(str(mac).encode()).hexdigest()[:16]
    except Exception as e:
        log_debug(f"HWID error: {e}")
        return hashlib.sha256(str(uuid.getnode()).encode()).hexdigest()[:16]

async def check_license() -> bool:
    license_key = CONFIG.get("LICENSE_KEY")
    github_url = CONFIG.get("GITHUB_LICENSE_URL")

    if not license_key:
        console.print("[red]❌ В config.json не указан LICENSE_KEY[/red]")
        return False
    if not github_url:
        console.print("[red]❌ В config.json не указан GITHUB_LICENSE_URL[/red]")
        return False

    headers = {
        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36',
        'Accept': 'application/json, text/plain, */*',
        'Accept-Language': 'ru-RU,ru;q=0.9,en-US;q=0.8,en;q=0.7',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache'
    }

    try:
        async with aiohttp.ClientSession() as session:
            async with session.get(github_url, headers=headers) as response:
                if response.status != 200:
                    console.print(f"[red]❌ Не удалось загрузить файл лицензий (HTTP {response.status})[/red]")
                    return False

                try:
                    text_data = await response.text()
                    licenses = json.loads(text_data)
                except Exception as e:
                    console.print(f"[red]❌ Ответ не является JSON: {e}[/red]")
                    return False

                if license_key not in licenses:
                    console.print("[red]❌ Лицензионный ключ не найден[/red]")
                    return False

                key_data = licenses[license_key]

                expire_str = key_data.get("expire")
                if expire_str:
                    expire_date = datetime.datetime.strptime(expire_str, "%Y-%m-%d").date()
                    if expire_date < datetime.date.today():
                        console.print(f"[red]❌ Срок действия лицензии истёк {expire_str}[/red]")
                        return False

                required_hwid = key_data.get("hwid")
                if required_hwid:
                    current_hwid = get_hwid()
                    if required_hwid != current_hwid:
                        console.print("[red]❌ Лицензия привязана к другому компьютеру[/red]")
                        log_debug(f"HWID mismatch: required {required_hwid}, got {current_hwid}")
                        return False

                console.print(f"[green]✅ Лицензия действительна до {expire_str if expire_str else 'бессрочно'}[/green]")
                return True

    except aiohttp.ClientError as e:
        console.print(f"[red]❌ Ошибка соединения с GitHub: {e}[/red]")
        return False
    except Exception as e:
        console.print(f"[red]❌ Ошибка проверки лицензии: {e}[/red]")
        return False

# --- ОСТАЛЬНЫЕ ФУНКЦИИ ---
async def send_telegram(message: str):
    try:
        if CONFIG.get("TELEGRAM_BOT_TOKEN") and CONFIG.get("TELEGRAM_CHAT_ID"):
            url = f"https://api.telegram.org/bot{CONFIG['TELEGRAM_BOT_TOKEN']}/sendMessage"
            async with aiohttp.ClientSession() as session:
                await session.post(url, json={
                    "chat_id": CONFIG["TELEGRAM_CHAT_ID"],
                    "text": message,
                    "parse_mode": "HTML"
                })
    except Exception as e:
        log_debug(f"Telegram error: {e}")

async def check_capmonster_balance():
    if not CONFIG.get("CHECK_BALANCE", True):
        return True
    try:
        result = await cap_client.get_balance()
        if isinstance(result, dict):
            balance = result.get('balance', 0)
        else:
            balance = float(result)
        if balance < 1.0:
            console.print(f"[red]⚠️ Мало средств на CapMonster: ${balance:.2f}. Пополните баланс.[/red]")
            log_debug(f"Low balance: ${balance:.2f}")
            return False
        console.print(f"[green]✓ Баланс CapMonster: ${balance:.2f}[/green]")
        return True
    except Exception as e:
        console.print(f"[red]Не удалось проверить баланс CapMonster: {e}[/red]")
        return False

def load_proxies() -> List[str]:
    proxy_file = CONFIG.get("PROXY_FILE", "proxies.txt")
    if not os.path.exists(proxy_file):
        return []
    with open(proxy_file, "r", encoding="utf-8") as f:
        proxies = [line.strip() for line in f if line.strip()]
    return proxies

def rotate_mullvad_country() -> str:
    countries = CONFIG.get("MULLVAD_COUNTRIES", ["us"])
    new_country = random.choice(countries)
    CONFIG["MULLVAD_COUNTRY"] = new_country
    return new_country

def check_mullvad_available() -> bool:
    try:
        result = subprocess.run(["mullvad", "--version"], capture_output=True, text=True, timeout=5)
        return result.returncode == 0
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return False

def rotate_mullvad_ip(change_country: bool = False) -> bool:
    if not check_mullvad_available():
        console.print("[bold red]Mullvad не найден![/bold red]")
        log_debug("Mullvad not found")
        return False

    try:
        if change_country:
            new_country = rotate_mullvad_country()
            console.print(f"[yellow]Смена страны Mullvad на {new_country}[/yellow]")
            subprocess.run(["mullvad", "relay", "set", "location", new_country], check=False)

        subprocess.run(["mullvad", "disconnect"], check=False)
        time.sleep(2)
        subprocess.run(["mullvad", "connect"], check=False)

        for _ in range(30):
            st = subprocess.run(["mullvad", "status"], capture_output=True, text=True).stdout
            if "Connected" in st:
                time.sleep(3)
                log_debug(f"IP rotated to {CONFIG['MULLVAD_COUNTRY']}")
                return True
            time.sleep(1)
        return False
    except Exception as e:
        log_debug(f"IP rotation error: {e}")
        return False

async def is_blocked(page: Page) -> bool:
    txt = (await page.content()).lower()
    return "sorry, you have been blocked" in txt or "rate limited" in txt

async def is_request_failed(page: Page) -> bool:
    try:
        content = await page.content()
        return "request failed" in content.lower() or "please go back and try again" in content.lower()
    except Exception:
        return False

async def detect_turnstile(page: Page) -> tuple[bool, str | None]:
    try:
        result = await page.evaluate(
            """
            () => {
                const text = document.body.innerText.toLowerCase();
                const url = window.location.href.toLowerCase();
                const markers = [
                    'cf-turnstile',
                    'verify you are human',
                    'checking your browser',
                    'подтвердите, что вы человек',
                    'internalcaptcha'
                ];
                let hasCaptcha = markers.some(m => text.includes(m)) || url.includes('internalcaptcha');

                let el = document.querySelector('[data-sitekey]');
                if (el) {
                    hasCaptcha = true;
                    return { hasCaptcha, sitekey: el.getAttribute('data-sitekey') || null };
                }

                const iframes = Array.from(document.querySelectorAll('iframe'));
                for (const fr of iframes) {
                    const src = (fr.getAttribute('src') || '').toLowerCase();
                    if (
                        src.includes('challenges.cloudflare.com') ||
                        src.includes('cloudflare.com') ||
                        src.includes('turnstile')
                    ) {
                        hasCaptcha = true;
                        try {
                            const u = new URL(fr.src);
                            const sk = u.searchParams.get('sitekey');
                            return { hasCaptcha, sitekey: sk };
                        } catch (e) {
                            return { hasCaptcha, sitekey: null };
                        }
                    }
                }

                return { hasCaptcha, sitekey: null };
            }
            """
        )
        return bool(result.get("hasCaptcha")), result.get("sitekey")
    except Exception:
        return False, None

async def solve_captcha_auto(page: Page, status_dict: dict, thread_id: int, max_attempts: int = 3) -> bool:
    try:
        for attempt in range(1, max_attempts + 1):
            await asyncio.sleep(2)

            has_captcha, sitekey = await detect_turnstile(page)
            if not has_captcha:
                try:
                    await page.wait_for_selector(f"{CONFIG['SEL_INPUT']}, .card-summary, .row.pl-1.record-count", timeout=5000)
                except:
                    pass
                return True

            if not sitekey:
                if SIMPLE_MODE:
                    print(f"🧩 [поток {thread_id}] Капча найдена, sitekey ещё не доступен (попытка {attempt})", flush=True)
                continue

            if SIMPLE_MODE:
                print(f"🧩 [поток {thread_id}] Решение капчи {sitekey[:8]}..., попытка {attempt}", flush=True)

            task = TurnstileRequest(websiteURL=page.url, websiteKey=sitekey)
            result = await cap_client.solve_captcha(task)
            token = result.get("token") if isinstance(result, dict) else None
            if not token:
                if SIMPLE_MODE:
                    print(f"❌ [поток {thread_id}] CapMonster не вернул токен", flush=True)
                continue

            if SIMPLE_MODE:
                print(f"🔑 [поток {thread_id}] Токен получен, вставляю...", flush=True)

            await page.evaluate(
                """(token) => {
                    const el = document.querySelector('[name="cf-turnstile-response"]');
                    if (el) {
                        el.value = token;
                        el.dispatchEvent(new Event('change', { bubbles: true }));
                    }
                }""",
                token,
            )

            for _ in range(10):
                await asyncio.sleep(2)

                html_after = await page.content()
                if "automatic submission failed" in html_after.lower():
                    try:
                        retry_btn = page.locator("text='Submit'")
                        if await retry_btn.is_visible():
                            if SIMPLE_MODE:
                                print(f"🔄 [поток {thread_id}] Повторный Submit после ошибки", flush=True)
                            await retry_btn.click()
                            await asyncio.sleep(3)
                    except Exception:
                        pass

                try:
                    manual_div = page.locator("#manualSubmit")
                    if await manual_div.is_visible():
                        if SIMPLE_MODE:
                            print(f"🖱️ [поток {thread_id}] Нажимаю кнопку капчи", flush=True)
                        await manual_div.locator("button").click()
                except Exception:
                    pass

                still_captcha, _ = await detect_turnstile(page)
                if not still_captcha:
                    try:
                        await page.wait_for_selector(f"{CONFIG['SEL_INPUT']}, .card-summary, .row.pl-1.record-count", timeout=5000)
                    except:
                        pass
                    if SIMPLE_MODE:
                        print(f"✅ [поток {thread_id}] Капча пройдена", flush=True)
                    return True

            if SIMPLE_MODE:
                print(f"❌ [поток {thread_id}] Не удалось пройти капчу после {attempt} попыток", flush=True)

        return False
    except Exception as e:
        if SIMPLE_MODE:
            print(f"❌ [поток {thread_id}] Ошибка CapMonster: {e}", flush=True)
        return False

async def ensure_no_captcha(page: Page, status_dict: dict, thread_id: int) -> bool:
    has_captcha, _ = await detect_turnstile(page)
    if not has_captcha:
        return True
    solved = await solve_captcha_auto(page, status_dict, thread_id)
    if not solved:
        if SIMPLE_MODE:
            print(f"❌ [поток {thread_id}] Капча осталась на странице", flush=True)
    return solved

def remove_number_from_file(phone: str) -> None:
    if not os.path.exists(CONFIG["INPUT_FILE"]):
        return
    try:
        with open(CONFIG["INPUT_FILE"], "r", encoding="utf-8") as f:
            lines = f.readlines()

        new_lines = []
        removed = False
        for line in lines:
            parts = line.strip().split()
            if not parts:
                new_lines.append(line)
                continue
            line_phone = re.sub(r"\D", "", parts[0])[:10]
            if line_phone != phone:
                new_lines.append(line)
            else:
                removed = True
                if SIMPLE_MODE:
                    print(f"🗑️ Удаляю номер {phone} из файла", flush=True)

        if removed:
            with open(CONFIG["INPUT_FILE"], "w", encoding="utf-8") as f:
                f.writelines(new_lines)
            if SIMPLE_MODE:
                print(f"✅ Номер {phone} удалён из {CONFIG['INPUT_FILE']}", flush=True)
        else:
            if SIMPLE_MODE:
                print(f"⚠️ Номер {phone} не найден в файле {CONFIG['INPUT_FILE']} (возможно, уже удалён)", flush=True)
    except Exception as e:
        if SIMPLE_MODE:
            print(f"❌ Ошибка при удалении номера {phone} из файла: {e}", flush=True)

async def parse_profile(page: Page, phone: str, phone_date: str, found_age: str, start_t: float, db_storage: Optional[NeonStorage] = None) -> None:
    global processed_success
    name = (await page.inner_text("h1.oh1")).strip()
    full_page_text = await page.inner_text("body")

    born_m = re.search(r"Born\s+([A-Za-z]+\s+\d{4})", full_page_text)
    born_info = born_m.group(1) if born_m else "N/A"

    county_info = "N/A"
    all_dt_sb = page.locator("span.dt-sb")
    count_sb = await all_dt_sb.count()
    for k in range(count_sb):
        text_sb = await all_dt_sb.nth(k).inner_text()
        if "County" in text_sb:
            county_info = text_sb.strip()
            break

    addr_el = page.locator("a[data-link-to-more='address']")
    all_addrs: list[str] = []
    for j in range(await addr_el.count()):
        p_text = (await addr_el.nth(j).inner_text()).replace("\n", ", ").strip()
        if p_text and p_text not in all_addrs:
            all_addrs.append(p_text)

    curr_addr = all_addrs[0] if all_addrs else "N/A"
    prev_list = all_addrs[1:] if len(all_addrs) > 1 else []

    with open(CONFIG["RESULT_FILE"], "a", encoding="utf-8") as f:
        f.write(
            f"{'='*60}\n"
            f"PHONE: {phone}\t{phone_date}\n"
            f"NAME: {name}\n"
            f"AGE: {found_age}\n"
            f"BORN: {born_info}\n"
            f"COUNTY: {county_info}\n"
            f"ADDR: {curr_addr}\n"
            f"PREV:\n"
            + ("\n".join(prev_list) if prev_list else "None")
            + f"\n{'='*60}\n\n"
        )

    stats["success"] += 1
    stats["consecutive_bans"] = 0
    processed_success.add(phone)
    if SIMPLE_MODE:
        print(f"💾 [поток] Сохранён профиль: {phone}, возраст {found_age}, имя {name}", flush=True)
    try:
        winsound.Beep(1000, 150)
    except Exception:
        pass
    asyncio.create_task(send_telegram(f"✅ Найден профиль: {phone}, возраст {found_age}"))
    
    # Сохраняем номер в общую базу данных Neon
    if db_storage:
        db_storage.add_phone(phone)

async def process_phone(page: Page, phone: str, context, status_dict: dict, thread_id: int, db_storage: Optional[NeonStorage] = None) -> str:
    global processed_success

    # Проверка по локальному кешу успешных (для этой сессии)
    if phone in processed_success:
        if SIMPLE_MODE:
            print(f"⏭️ [поток {thread_id}] Номер {phone} уже обработан (локально), пропускаем", flush=True)
        return "done"

    # Проверка по базе данных (глобальный список)
    if db_storage and db_storage.phone_exists(phone):
        if SIMPLE_MODE:
            print(f"⏭️ [поток {thread_id}] Номер {phone} уже обработан (в БД), пропускаем", flush=True)
        return "done"

    start_t = time.time()
    min_age = CONFIG.get("MIN_AGE", 30)
    max_age = CONFIG.get("MAX_AGE", 55)
    captcha_fail_count = 0
    max_captcha_fails = 2
    post_captcha_attempts = 0
    max_post_captcha_attempts = 2

    if SIMPLE_MODE:
        print(f"📞 [поток {thread_id}] Начинаю обработку номера {phone}", flush=True)

    try:
        # --- Переход на главную ---
        try:
            await page.goto("https://www.truepeoplesearch.com/", wait_until="domcontentloaded", timeout=30000)
        except Exception as e:
            if SIMPLE_MODE:
                print(f"⚠️ [поток {thread_id}] Ошибка загрузки главной: {e}", flush=True)
            return "retry"

        if await is_blocked(page) or await is_request_failed(page):
            if SIMPLE_MODE:
                print(f"🚫 [поток {thread_id}] Обнаружен бан на главной", flush=True)
            return "banned"

        if not await ensure_no_captcha(page, status_dict, thread_id):
            captcha_fail_count += 1
            if captcha_fail_count >= max_captcha_fails:
                if SIMPLE_MODE:
                    print(f"🚫 [поток {thread_id}] Слишком много ошибок капчи для номера {phone}, считаем баном", flush=True)
                return "banned"
            return "retry"

        if not await page.is_visible(CONFIG["SEL_INPUT"]):
            await page.click(CONFIG["SEL_PHONE_TAB"])
            await asyncio.sleep(1)

        if SIMPLE_MODE:
            print(f"⌨️ [поток {thread_id}] Ввод номера {phone}", flush=True)
        await page.click(CONFIG["SEL_INPUT"], click_count=3)
        await page.keyboard.press("Backspace")
        await page.type(CONFIG["SEL_INPUT"], phone, delay=random.randint(50, 150))
        await page.click(CONFIG["SEL_SUBMIT"])
        await ensure_no_captcha(page, status_dict, thread_id)

        steps = CONFIG["SEARCH_WAIT_TIMEOUT"] // 2
        if steps < 3:
            steps = 3

        for step in range(steps):
            await asyncio.sleep(2)

            if await is_blocked(page) or await is_request_failed(page):
                if SIMPLE_MODE:
                    print(f"🚫 [поток {thread_id}] Обнаружен бан при поиске", flush=True)
                return "banned"

            if not await ensure_no_captcha(page, status_dict, thread_id):
                captcha_fail_count += 1
                if captcha_fail_count >= max_captcha_fails:
                    if SIMPLE_MODE:
                        print(f"🚫 [поток {thread_id}] Слишком много ошибок капчи для номера {phone}, считаем баном", flush=True)
                    return "banned"
                continue

            try:
                await page.wait_for_selector(".card-summary, .col-md-8, .row.pl-1.record-count", timeout=5000)
            except:
                pass

            content_now = (await page.content()).lower()
            no_record_phrases = [
                "could not find any records",
                "we could not find any records for that search criteria"
            ]
            if any(phrase in content_now for phrase in no_record_phrases):
                if SIMPLE_MODE:
                    print(f"🗑️ [поток {thread_id}] Номер {phone} не найден (trash)", flush=True)
                return "trash"

            results = page.locator(".col-md-8, .card-summary")
            if await results.count() > 0:
                profile_urls = []
                for i in range(await results.count()):
                    res_block = results.nth(i)
                    text = await res_block.inner_text()
                    age_m = re.search(r"Age (\d+)", text)
                    if not age_m:
                        continue
                    age_val = int(age_m.group(1))
                    if min_age <= age_val <= max_age:
                        link_selectors = [
                            ".content-header a",
                            "a.btn",
                            "a[href*='/l/']",
                            "a:has-text('View Details')",
                            "a[data-link-to-more='profile']",
                            ".btn.btn-primary",
                            ".card-summary a[href]"
                        ]
                        href = None
                        for selector in link_selectors:
                            link = res_block.locator(selector).first
                            if await link.count() > 0:
                                href = await link.get_attribute("href")
                                if href:
                                    break
                        if href:
                            full_url = href if href.startswith("http") else "https://www.truepeoplesearch.com" + href
                            profile_urls.append((full_url, age_m.group(1)))
                            if SIMPLE_MODE:
                                print(f"  ✅ Найдена ссылка на профиль: {full_url}", flush=True)
                        else:
                            if SIMPLE_MODE:
                                print(f"⚠️ [поток {thread_id}] Не удалось найти ссылку в карточке {i}", flush=True)

                if profile_urls:
                    if SIMPLE_MODE:
                        print(f"🔗 [поток {thread_id}] Найдено {len(profile_urls)} подходящих профилей", flush=True)

                    for idx, (profile_url, found_age) in enumerate(profile_urls, 1):
                        if SIMPLE_MODE:
                            print(f"  → Профиль {idx}/{len(profile_urls)} (возраст {found_age})", flush=True)

                        profile_page = await context.new_page()
                        try:
                            await profile_page.goto(profile_url, wait_until="domcontentloaded", timeout=15000)
                            if await is_blocked(profile_page) or await is_request_failed(profile_page):
                                if SIMPLE_MODE:
                                    print(f"  ⚠️ Ошибка при загрузке профиля {idx}, пропускаю", flush=True)
                                continue

                            await ensure_no_captcha(profile_page, status_dict, thread_id)

                            try:
                                await profile_page.wait_for_selector("h1.oh1", timeout=15000)
                            except Exception:
                                if SIMPLE_MODE:
                                    print(f"  ⚠️ Заголовок профиля не найден, пропускаю", flush=True)
                                continue

                            phone_date = PHONE_DATES.get(phone, time.strftime("%Y-%m-%d"))
                            await parse_profile(profile_page, phone, phone_date, found_age, start_t, db_storage)
                        except Exception as e:
                            if SIMPLE_MODE:
                                print(f"  ❌ Ошибка при парсинге профиля: {e}", flush=True)
                        finally:
                            await profile_page.close()

                    return "done"
                else:
                    if SIMPLE_MODE:
                        print(f"ℹ️ [поток {thread_id}] Найдены карточки, но не удалось получить ссылки или возраст вне диапазона", flush=True)
                    return "done"

            if await page.is_visible(CONFIG["SEL_INPUT"]):
                post_captcha_attempts += 1
                if post_captcha_attempts >= max_post_captcha_attempts:
                    if SIMPLE_MODE:
                        print(f"🗑️ [поток {thread_id}] После капчи нет результатов (превышено число попыток), номер {phone} считается пустым", flush=True)
                    return "trash"
                if SIMPLE_MODE:
                    print(f"🔄 [поток {thread_id}] После капчи снова поле ввода, повторный поиск (попытка {post_captcha_attempts})...", flush=True)
                await page.click(CONFIG["SEL_SUBMIT"])
                continue

        if SIMPLE_MODE:
            print(f"⏳ [поток {thread_id}] Время поиска истекло, номер {phone} будет повторен позже", flush=True)
        return "retry"

    except Exception as e:
        if SIMPLE_MODE:
            print(f"❌ [поток {thread_id}] Критическая ошибка: {e}", flush=True)
        return "retry"
        
async def worker(phone_queue: asyncio.Queue, status_dict: dict, thread_id: int, proxy: Optional[str] = None, db_storage: Optional[NeonStorage] = None) -> None:
    proxy_config = None
    if proxy:
        if not proxy.startswith(("http://", "socks5://")):
            proxy = f"socks5://{proxy}"
        proxy_config = {"server": proxy}

    async with async_playwright() as p:
        context = await p.chromium.launch_persistent_context(
            os.path.abspath(f"./prof_{thread_id}"),
            executable_path=CONFIG["CHROME_PATH"],
            headless=False,
            proxy=proxy_config,
            args=[
                "--disable-blink-features=AutomationControlled",
                "--disable-session-crashed-bubble",
            ],
        )
        page = await context.new_page()

        while not phone_queue.empty():
            phone = await phone_queue.get()
            res = await process_phone(page, phone, context, status_dict, thread_id, db_storage)

            if res == "done":
                pass
            elif res == "trash":
                stats["trash"] += 1
                if db_storage:
                    db_storage.add_phone(phone)
            elif res == "banned":
                stats["banned"] += 1
                stats["consecutive_bans"] += 1
            elif res == "retry":
                stats["retry"] += 1

            if res == "done" or res == "trash":
                remove_number_from_file(phone)
                phone_queue.task_done()
                await asyncio.sleep(random.uniform(CONFIG["MIN_DELAY_BETWEEN"], CONFIG["MAX_DELAY_BETWEEN"]))
            elif res == "banned":
                await phone_queue.put(phone)
                if SIMPLE_MODE:
                    print(f"🔄 [поток {thread_id}] Бан, меняю IP...", flush=True)
                change_country = stats["consecutive_bans"] >= CONFIG.get("MAX_CONSECUTIVE_BANS", 3)
                if CONFIG["USE_MULLVAD"]:
                    rotate_mullvad_ip(change_country)
                elif proxy:
                    pass

                if change_country:
                    penalty = CONFIG.get("BAN_PENALTY_SECONDS", 30)
                    if SIMPLE_MODE:
                        print(f"⏸️ [поток {thread_id}] Много банов, пауза {penalty}с", flush=True)
                    await asyncio.sleep(penalty)
                    stats["consecutive_bans"] = 0

                await asyncio.sleep(5)
            else:
                await phone_queue.put(phone)
                await asyncio.sleep(10)

        await context.close()

def save_queue_backup(queue_items: list):
    with open("queue_backup.txt", "w", encoding="utf-8") as f:
        for phone in queue_items:
            f.write(f"{phone}\n")
    console.print("[yellow]Очередь сохранена в queue_backup.txt[/yellow]")
    log_debug(f"Queue backup saved: {len(queue_items)} items")

def load_queue_backup() -> list:
    if not os.path.exists("queue_backup.txt"):
        return []
    with open("queue_backup.txt", "r", encoding="utf-8") as f:
        items = [line.strip() for line in f if line.strip()]
    return items

def format_time(seconds: float) -> str:
    return str(datetime.timedelta(seconds=int(seconds)))

def get_progress_bar(percent: float, width: int = 20) -> str:
    filled = int(percent * width)
    bar = "█" * filled + "░" * (width - filled)
    return f"[{bar}] {percent:.1%}"

async def main():
    global SIMPLE_MODE, processed_success

    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--no-restore', action='store_true', help='Не спрашивать о восстановлении очереди')
    parser.add_argument('--simple-output', action='store_true', help='Отключить rich.Live (для GUI)')
    parser.add_argument('--auto-install', action='store_true', help='Автоматически устанавливать зависимости')
    args, unknown = parser.parse_known_args()
    SIMPLE_MODE = args.simple_output

    # 1. Проверка лицензии
    if not await check_license():
        if SIMPLE_MODE:
            print("❌ Проверка лицензии не пройдена. Выход.", flush=True)
        return

    # 2. Проверка баланса CapMonster
    if not await check_capmonster_balance():
        if SIMPLE_MODE:
            print("❌ Проверка баланса не пройдена. Выход.", flush=True)
        return

    # 3. Инициализация NeonStorage (общая база данных)
    db_storage = None
    if CONFIG.get("NEON_DSN"):
        try:
            db_storage = NeonStorage(CONFIG["NEON_DSN"])
            if SIMPLE_MODE:
                print("✅ Подключение к Neon установлено")
        except Exception as e:
            if SIMPLE_MODE:
                print(f"⚠️ Ошибка подключения к Neon: {e}. Работаем без облачной синхронизации.")
    else:
        if SIMPLE_MODE:
            print("ℹ️ NEON_DSN не задан, работаем без облачной синхронизации.")

    # 4. Проверка Mullvad или загрузка прокси
    proxies = []
    if CONFIG["USE_MULLVAD"]:
        if not check_mullvad_available():
            console.print("[bold red]Mullvad не найден! Отключите USE_MULLVAD или используйте PROXY_FILE.[/bold red]")
            if SIMPLE_MODE:
                print("❌ Mullvad не найден!", flush=True)
            return
    else:
        proxies = load_proxies()
        if not proxies:
            console.print("[yellow]Прокси не найдены, работа без прокси.[/yellow]")
            if SIMPLE_MODE:
                print("ℹ️ Прокси не найдены, работа без прокси.", flush=True)
        else:
            console.print(f"[green]Загружено {len(proxies)} прокси[/green]")
            if SIMPLE_MODE:
                print(f"✅ Загружено {len(proxies)} прокси", flush=True)

    # 5. Загружаем уже обработанные номера из локальных файлов (trash и success_list)
    trash_nums = set()
    if os.path.exists(CONFIG["TRASH_FILE"]):
        with open(CONFIG["TRASH_FILE"], "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                digits = re.sub(r"\D", "", line)[:10]
                if digits:
                    trash_nums.add(digits)

    success_history = set()
    success_file = "success_list.txt"
    if os.path.exists(success_file):
        with open(success_file, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                digits = re.sub(r"\D", "", line)[:10]
                if digits:
                    success_history.add(digits)
    processed_success.update(success_history)

    # Объединяем локальные множества (база данных будет проверяться отдельно)
    processed_set = set(trash_nums) | set(success_history) | set(processed_success)

    # 6. Восстановление очереди из бэкапа (если есть)
    backup = load_queue_backup()
    if backup and not args.no_restore:
        console.print("[yellow]Найден сохранённый бэкап очереди.[/yellow]")
        if SIMPLE_MODE:
            print("📦 Найден сохранённый бэкап очереди.", flush=True)
        answer = input("Восстановить последнюю сессию? (y/n): ").lower()
        if answer == 'y':
            nums_to_process = backup
            console.print(f"[green]Загружено {len(nums_to_process)} номеров из бэкапа[/green]")
            if SIMPLE_MODE:
                print(f"✅ Загружено {len(nums_to_process)} номеров из бэкапа", flush=True)
            os.remove("queue_backup.txt")
        else:
            nums_to_process = []
    elif backup and args.no_restore:
        console.print("[yellow]Найден бэкап очереди, но восстановление отключено (флаг --no-restore).[/yellow]")
        if SIMPLE_MODE:
            print("📦 Найден бэкап очереди, но восстановление отключено (флаг --no-restore).", flush=True)
        nums_to_process = []
    else:
        nums_to_process = []

    # Если не восстанавливали из бэкапа, читаем из входного файла
    if not nums_to_process:
        if not os.path.exists(CONFIG["INPUT_FILE"]):
            console.print(f"[red]Файл {CONFIG['INPUT_FILE']} не найден[/red]")
            if SIMPLE_MODE:
                print(f"❌ Файл {CONFIG['INPUT_FILE']} не найден", flush=True)
            return

        global PHONE_DATES
        PHONE_DATES = {}
        nums_to_process = []
        seen = set()

        with open(CONFIG["INPUT_FILE"], "r", encoding="utf-8") as f:
            for line in f:
                if not line.strip() or line.startswith("号码"):
                    continue
                parts = line.strip().split()
                if not parts:
                    continue

                digits = re.sub(r"\D", "", parts[0])
                if len(digits) < 10:
                    continue
                phone = digits[:10]

                # Проверяем только по локальным файлам (база данных будет проверяться в process_phone)
                if phone in processed_set or phone in seen:
                    continue

                date_str = parts[1] if len(parts) > 1 else time.strftime("%Y-%m-%d")
                nums_to_process.append(phone)
                PHONE_DATES[phone] = date_str
                seen.add(phone)

    if not nums_to_process:
        console.print("[yellow]Все номера уже обработаны или файл пуст.[/yellow]")
        if SIMPLE_MODE:
            print("ℹ️ Все номера уже обработаны или файл пуст.", flush=True)
        return

    stats["total_unique"] = len(nums_to_process)
    if SIMPLE_MODE:
        print(f"TOTAL:{stats['total_unique']}", flush=True)
    # Перемешиваем номера для случайного порядка
    random.shuffle(nums_to_process)
    q: asyncio.Queue[str] = asyncio.Queue()
    for n in nums_to_process:
        await q.put(n)

    status_dict = {i: "Запуск" for i in range(CONFIG["THREADS"])}

    loop = asyncio.get_running_loop()

    def signal_handler():
        console.print("\n[bold red]Получен сигнал остановки. Сохраняю данные и очередь...[/bold red]")
        if SIMPLE_MODE:
            print("\n🛑 Получен сигнал остановки. Сохраняю данные и очередь...", flush=True)
        remaining = []
        while not q.empty():
            remaining.append(q.get_nowait())
        save_queue_backup(remaining)
        # Сохранять в Neon не нужно, так как номера уже добавились по одному
        asyncio.create_task(send_telegram("🛑 Скрипт остановлен. Очередь сохранена."))
        time.sleep(1)
        os._exit(0)

    if sys.platform != "win32":
        for sig in (signal.SIGINT, signal.SIGTERM):
            loop.add_signal_handler(sig, signal_handler)
    else:
        signal.signal(signal.SIGINT, lambda s, f: signal_handler())
        signal.signal(signal.SIGTERM, lambda s, f: signal_handler())

    if SIMPLE_MODE:
        tasks = []
        for i in range(CONFIG["THREADS"]):
            proxy = proxies[i % len(proxies)] if proxies else None
            tasks.append(asyncio.create_task(worker(q, status_dict, i, proxy, db_storage)))
        await asyncio.gather(*tasks)
        print("✅ Парсер завершил работу.", flush=True)
    else:
        with Live(Table(), refresh_per_second=4) as live:
            tasks = []
            for i in range(CONFIG["THREADS"]):
                proxy = proxies[i % len(proxies)] if proxies else None
                tasks.append(asyncio.create_task(worker(q, status_dict, i, proxy, db_storage)))
            try:
                while not all(t.done() for t in tasks):
                    processed = stats["success"] + stats["trash"]
                    percent = processed / stats["total_unique"] if stats["total_unique"] > 0 else 0
                    progress_bar = get_progress_bar(percent)
                    elapsed = time.time() - stats["start_time"]
                    time_str = format_time(elapsed)

                    table = Table(title=f"TPS Parser v6.2 (Licensed)  |  Время: {time_str}")
                    table.add_column("Поток", style="bold cyan")
                    table.add_column("Статус", style="bold")
                    table.add_column("Статистика")

                    table.add_row(
                        "📊 Прогресс",
                        progress_bar,
                        f"{processed}/{stats['total_unique']}",
                        end_section=True
                    )
                    ban_info = f" | Баны подряд: {stats['consecutive_bans']}" if stats['consecutive_bans'] > 0 else ""
                    table.add_row(
                        "📈 Всего",
                        f"[green]Успех: {stats['success']}[/green] | [yellow]Trash: {stats['trash']}[/yellow] | [red]Бан: {stats['banned']}[/red] | [blue]Повтор: {stats['retry']}[/blue]{ban_info}",
                        f"Очередь: {q.qsize()}"
                    )
                    table.add_row("─" * 10, "─" * 10, "─" * 25)

                    for t_id, status in status_dict.items():
                        status_text = Text.from_markup(status) if status else Text("")
                        table.add_row(f"Thread #{t_id}", status_text, "")

                    live.update(table)
                    await asyncio.sleep(0.5)
            finally:
                remaining = []
                while not q.empty():
                    remaining.append(q.get_nowait())
                if remaining:
                    save_queue_backup(remaining)
                    await send_telegram(f"🛑 Скрипт завершён. Осталось {len(remaining)} номеров.")

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        console.print("\n[bold red]Остановлено пользователем.[/bold red]")
        if SIMPLE_MODE:
            print("\n🛑 Остановлено пользователем.", flush=True)
    finally:
        if debug_log:
            debug_log.close()